const Discord = require('discord.js');
const fetch = require('node-fetch')
const express = require('express');
const app = express();
const client = new Discord.Client({
  disableEveryone: true
});
const yts = require('yt-search');

client.commands = new Discord.Collection();
client.aliases = new Discord.Collection();
client.config = require('./config')
client.queue = new Map()
client.snipes = new Map()

module.exports = client;

["Command", "Event"].forEach(handler => {
  require(`./Handlers/${handler}`)(client);
});

const { Player } = require("discord-music-player");

const player = new Player(client, {
    leaveOnEnd: false,
    leaveOnStop: false,
    leaveOnEmpty: false,
    timeout: 10,
    volume: 200,
    quality: 'high',
});

app.get('/', function(req, res) {
	res.sendFile(__dirname + '/webserver/index.html');
})

app.get('/commands', function(req, res) {
  res.sendFile(__dirname + '/webserver/commands.html')
})

app.get('/support', function(req, res) {
  res.sendFile(__dirname + '/webserver/support.html')
})

app.get('/invite', function(req, res) {
  res.sendFile(__dirname + '/webserver/invite.html')
})

app.get('/docs', function(req, res) {
  res.sendFile(__dirname + '/webserver/docs.html')
})

app.get('/mountain', function(req, res) {
  res.sendFile(__dirname + '/photo.jpg')
})

app.get('*', function(req, res) {
  res.status(404).sendFile(__dirname + '/webserver/404.html')
})

app.listen(process.env.PORT, () => console.log(`Webserver listening to ` + process.env.PORT));

client.on("ready", () => {
  client.user.setStatus("idle")
  console.log("Yokaze is Ready")
  client.user.setActivity(`${client.config.prefix}help | ${client.config.prefix}invite `, { type: "PLAYING"})
})

client.login(process.env.TOKEN);