const { fetchMember } = require('../../tools');
const { createSuccessEmbed, improperUsage } = require('../../utils/embed');

module.exports = {
  name: "ban2",
  aliases: ['banned'],
  description: "Banned member",
  usage: "ban <mention> [reason]",
  category: "Moderation",
  run: async(client, message, args) => {
    if(!message.member.hasPermission("BAN_MEMBERS")) {
      return message.channel.send("You don't have permission to ban members")
    }
    
    	let member;
	if (args[0]) {
		member = fetchMember(message, args[0]);
	}
	if (!member || typeof member !== 'object') {
		return message.channel.send(
			improperUsage(
				'Please specify a user you would like to ban. \nIf you do not want to ping them you may use their id.',
			),
		);
	}

	if (member.user.id === client.user.id) {
		return message.channel.send(
			improperUsage('How mean. You want to ban me? I wont ban myself :('),
		);
	}

	if (member.user.id === message.author.id) {
		return message.channel.send(
			improperUsage(
				'If you wish to leave the guild, I can not help you.',
			),
		);
	}

	if (member.user.id === message.guild.ownerID) {
		return message.channel.send(
			improperUsage('You may not ban the owner of the guild.'),
		);
	}
  
    if(member.roles.highest.rawPosition >= message.member.roles.highest.rawPosition || message.author.id !== message.guild.owner.id) {
      return message.reply(
        improperUsage(`They have more power than you`),
        );
    }

	let reason = args.slice(1).join(' ');
	reason = `${message.author.tag} Successfully banned ${member.user.tag}(${member.user.id}. ${
		!reason ? 'No reason was provided.' : `Reason for ban: ${reason}`
	}`;

	try {
		await member.ban({ reason });
	} catch (err) {
		console.log(err);
		return message.channel.send(
			improperUsage(
				'There was an error trying to ban this member. Please try again later.',
			),
		);
	}

	return message.channel.send(createSuccessEmbed(reason));
  }
}