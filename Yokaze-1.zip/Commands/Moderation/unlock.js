const Discord = module.require("discord.js");

module.exports = {
   name: "unlock",
   aliases: [''],
   description: "Unlocks a Channel",
   usage: "unlock <channel>",
   category: "Moderation",
   run: async(client, message, args) => {
   if (!message.member.hasPermission('MANAGE_SERVER', 'MANAGE_CHANNELS')) {
   return message.channel.send("You don't have enough Permissions")
   }
   message.channel.overwritePermissions([
     {
        id: message.guild.id,
        null : ['SEND_MESSAGES'],
     },
    ],);
   const embed = new Discord.MessageEmbed()
   .setTitle("Channel Updates")
   .setDescription(`🔓 ${message.channel}  has been Unlocked`)
   .setColor("#FF7300");
   await message.channel.send(embed);
   message.delete();
}
}