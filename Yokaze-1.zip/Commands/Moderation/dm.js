const { ownerID } = require('../../assets/config.json')
const Discord = require('discord.js')
const client = require('discord.js')

module.exports = {
      name: "dm",
      description: "DM a user in the guild",
      aliases: ['pm'],
    run: async (bot, message, args) => {
      if(!message.channel.permissionsFor(message.member).has("MANAGE_MESSAGES") && !ownerID.includes(message.author.id)) return;

      const sendedEmbed = new Discord.MessageEmbed()
      .setAuthor(`DM From ${message.author.tag}`, message.author.AvatarURL())
      .setThumbnail(client.user.AvatarURL({ dynamic: true }))
      .setDescription(args.slice(1).join(" "))
      .setFooter(client.user.username, client.user.AvatarURL())
      .setTimestamp()
      .setColor('#ff7300')

      const invalidEmbed = new Discord.MessageEmbed()
      .setAuthor('ERROR', message.author.AvatarURL())
      .setDescription(`You didn't mention user, or you gave an invalid id`)
      .setFooter(client.user.username, client.user.AvatarURL())
      .setTimestamp()
      .setColor('#ff7300')

      const noMsg = new Discord.MessageEmbed()
      .setAuthor('ERROR', message.author.AvatarURL())
      .setThumbnail(message.author.AvatarURL({ dynamic: true }))
      .setDescription(`You didn't specify your message to send`)
      .setFooter(client.user.user, client.user.AvatarURL())
      .setTimestamp()
      .setColor('#ff7300')

      let user =
        message.mentions.members.first() ||
        message.guild.members.cache.get(args[0]);
      if (!user)
        return message.channel.send(invalidEmbed);
      if (!args.slice(1).join(" "))
        return message.channel.send(noMsg);
      user.user
        .send(sendedEmbed)
        .catch(() => message.channel.send(":x: Occured ERROR"))
        .then(() => message.channel.send(`✅ Sent a message to ${user.user.tag}`));
    },
  };