const { createEmbed } = require('../../utils/embed')

module.exports = {
  name: "advice",
  aliases: ['advicefortoday'],
  category: "Fun",
  description: "Get some random advice from Yokaze.",
  usage: "advice",
  run: async (client, message, args) => {
    const result = require('https://api.adviceslip.com/advive')
    const adviveResult = JSON.parse(result.text)

    return message.channel.send(
      createEmbed({
        body: adviceResult.slip.advice,
        footer: `Advice Slip #${adviceResult.slip.id}`
      }),
    )
  }
}