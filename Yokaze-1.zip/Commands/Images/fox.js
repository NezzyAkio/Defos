const { createEmbed } = require('../../utils/embed')
const agent = require('superagent')
const { sendSomeRandomAnimalAPI } = require('../../utils/helper');

module.exports = {
  name: "fox",
  aliases: ['foxy'],
  description: "Get a random picture and fact of a fox.",
  usage: "fox",
  category: "Images",
  run: async(client, message, args) => {
    return sendSomeRandomAnimalAPI(message, 'fox')
  }
}