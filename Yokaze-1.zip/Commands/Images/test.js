const Discord = require('discord.js')
const fetch = require('node-fetch')

module.exports = {
  name: "test",
  aliases: [''],
  description: "",
  usage: "",
  category: "",
  run: async(client, message, args) => {
    let resURL = "https://api.yokaze.ml/klee?apikey=X3Z";

fetch(resURL)
.then(res => res.json())
.then(json => {
        const embed = new Discord.MessageEmbed()
            .setColor("FF7300")
            .setAuthor("Klee")
            .setDescription(`[Click here to see the full image](${json.url})`)
            .setImage(json.url)
            .setTimestamp()
          message.channel.send(embed)
}
)
.catch(error => console.log(error));
   }
}