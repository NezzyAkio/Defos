const { MessageEmbed } = require('discord.js');
const { formatTimeSince } = require('../../tools');
const { website, creatorID, creatorName: ownername } = require('../../assets/config.json');
const { primary } = require('../../assets/colors.json');

module.exports = {
  name: "botinfo",
  category: "info",
  aliases: ['binfo', 'botstats', 'stats'],
  description: 'Check\'s bot\'s status',
  usage: "botinfo",
  run: async (client, message, args, del, member) => {
    let servers_count = message.client.guilds.cache.size;
var myarray = [];
message.client.guilds.cache.keyArray().forEach(async function(item, index) {

let guildMember = message.client.guilds.cache.get(item).memberCount;
myarray.push(guildMember)
})
let sum = myarray.reduce(function (a, b) {
return a + b
});

let totalSeconds = message.client.uptime / 1000;
let days = Math.floor(totalSeconds / 86400);
totalSeconds %= 86400;
let hours = Math.floor(totalSeconds / 3600);
totalSeconds %= 3600;
let minutes = Math.floor(totalSeconds / 60);
let seconds = Math.floor(totalSeconds % 60);

let uptime = `\`\`\`${days} days, ${hours} hours, ${minutes} minutes and ${seconds} seconds\`\`\``;
      const e = new MessageEmbed()
		.setURL(website)
		.setColor(primary)
		.setTitle(client.user.username)
		.setThumbnail(client.user.displayAvatarURL({ format: 'png' }))
    .addFields(
    { name: "Servers:", value: `\`\`\`${servers_count}\`\`\``, inline: true },
    { name: "Users:", value: `\`\`\`${sum}\`\`\``, inline: true },
    { name: "Uptime: ", value: uptime , inline: true },
    { name: "Ping:",value: `\`\`\`${Math.round(message.client.ws.ping)} ms\`\`\``, inline: true },
    { name: "RAM: ", value: `\`\`\`${(process.memoryUsage().heapUsed / 1024 / 1024).toFixed(2)} MB\`\`\``, inline: true  },
    { name: "Bot Owner:",value: `\`\`\`${ownername}\`\`\``},
  )
		.setDescription(
			`**Link & Information About ${client.user.tag}**\n\n**Username**: <@!${client.user.id}> \n**Creator**: <@!${creatorID}> \n**Guilds**: ${client.guilds.cache.size} \n\n• [Invite ${client.user.username}](${website}invite) \n• [Join Support Server](${website}support)\n• [Vote for ${client.user.username}'s](https://top.gg/bot/${client.user.id}) \n• [${client.user.username}'s Website](${website})\n\n**Bot Statistic: **`,
		)
		.setFooter(`Uptime: ${formatTimeSince(client.uptime)}`)
		.setTimestamp();
	return message.channel.send(e);
  }
}
