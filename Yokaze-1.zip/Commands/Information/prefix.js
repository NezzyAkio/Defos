const Discord = require('discord.js')
const db = require('quick.db')
const default_prefix = require('../../config.json')

module.exports = {
  name: "prefix",
  aliases: [''],
  description: "To see prefix in current server",
  usage: "prefix",
  run: async(client, message, args) => {
    let prefix = db.get(`prefix_${message.guild.id}`)
    if(prefix === null) prefix = default_prefix;

    let prefixEmbed = new Discord.MessageEmbed()
    .setAuthor(`Prefix in ${message.guild.name}`, client.user.avatarURL())
    .setDescription(`Prefix is ${prefix}`)
    .setTimestamp()
    .setColor('#FF7300')
    message.channel.send(prefixEmbed)
  }
}