const { MessageEmbed } = require("discord.js");
const db = require("quick.db");

module.exports = {
        name: "addmoney",
        aliases: ["am"],
        category: "Economy",
        description: "Adds Money to a user",
        usage: "addmoney <mention || ID> <amount>",
    run: async (bot, message, args) => {
        if (message.author.id !== '883325860583702580') return message.channel.send("You do not have permission to use this command!");
        if (!args[0]) return message.channel.send("**Please Enter A User!**")

        let user = message.mentions.members.first() || message.guild.members.cache.get(args[0]) || message.guild.members.cache.find(r => r.user.username.toLowerCase() === args[0].toLocaleLowerCase()) || message.guild.members.cache.find(r => r.displayName.toLowerCase() === args[0].toLocaleLowerCase());
        if (!user) return message.channel.send("**Enter A Valid User!**")
        if (!args[1]) return message.channel.send("**Please Enter A Amount!**")
        if (isNaN(args[1])) return message.channel.send(`**❌ Your Amount Is Not A Number!**`);
        db.add(`money_${user.id}`, args[1])
        let bal = db.fetch(`money_${user.id}`)

        let moneyEmbed = new MessageEmbed()
            .setColor("#FF7300")
            .setDescription(`✅ Added ${args[1]} <:Lucky_Clover:878632026989817897>\n\n<:Lucky_Clover:878632026989817897> | New Balance: ${bal}`);
        message.channel.send(moneyEmbed)

    }
}