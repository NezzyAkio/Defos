const superagent = require('superagent');
const { MessageEmbed } = require('discord.js')

module.exports = {
  name: 'joke',
  aliases: [''],
  category: 'Fun',
  description: 'Display a random joke', 
  usage: "joke",
        run: async (client, message, args) => {
            await superagent
        .get('http://icanhazdadjoke.com/')
        .set('Accept', 'application/json')
		   .end((err, response) => {
        let jEmbed = new MessageEmbed()
        .setAuthor("Joke", message.author.avatarURL())
        .setDescription(response.body.joke)
        .setFooter(`Requested by ${message.author.username}`, message.author.avatarURL())
        .setTimestamp()
        .setColor('#FF7300')
        message.channel.send(jEmbed);
		})
    }
}