const { Random } = require("something-random-on-discord");
const random = new Random();
const Discord = require('discord.js');

module.exports = {
  name: "neko",
  aliases: [''],
  category: "Images",
  description: "Get some neko images",
  usage: "neko",
  run: async (client, message, args) => {
    let data = await random.getNeko()
    message.channel.send(data)
  }
}