const { createEmbed } = require('../../utils/embed')
const agent = require('superagent')
const { sendSomeRandomAnimalAPI } = require('../../utils/helper');

module.exports = {
  name: "koala",
  aliases: ['koalapo'],
  description: "Get a random picture and fact of a koala.",
  usage: "koala",
  category: "Images",
  run: async(client, message, args) => {
    return sendSomeRandomAnimalAPI(message, 'koala')
  }
}