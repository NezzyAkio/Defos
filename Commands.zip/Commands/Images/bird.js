const { createEmbed } = require('../../utils/embed')
const agent = require('superagent')
const { sendSomeRandomAnimalAPI } = require('../../utils/helper');
const birds = ['bird', 'birb']

module.exports = {
  name: "bird",
  aliases: [''],
  description: "Get a random picture and fact of a bird.",
  usage: "bird",
  category: "Images",
  run: async(client, message, args) => {
    var rand = birds[Math.floor(Math.random() * birds.length)]
    return sendSomeRandomAnimalAPI(message, rand)
  }
}