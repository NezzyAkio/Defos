const { readdirSync } = require('fs');
const ascii = require('ascii-table');
let table = new ascii("Events");
table.setHeading('Event', '     Status     ');

module.exports = (client) => {
    readdirSync('./Events/').forEach(dir => {
        const events = readdirSync(`./Events/`).filter(file => file.endsWith('.js'));
        for(let file of events) {
            let pull = require(`../Events/${file}`);
            if(pull.name) {
                client.events.set(pull.name, pull);
            } else {
                table.addRow(file, 'Loaded ✅')
                continue;
            } if(pull.aliases && Array.isArray(pull.aliases)) pull.aliases.forEach(alias => client.aliases.set(alias, pull.name))
        }
    });
    console.log(table.toString());
}