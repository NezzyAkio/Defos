const client = require('../index')

client.on('guildMemberAdd', async member => {
    let wChan = db.fetch(`welcome_${member.guild.id}`)
    if (wChan == null) return;
    if (!wChan) return;
  let welEmbed = new Discord.MessageEmbed()
  .setAuthor(`Welcome ${member.user.tag}`)  
  .setDescription(`Hello, ${member.user.tag} Welcome to ${member.guild.name} 🥳🥳🥳`)
  .setImage(`https://api.xzusfin.repl.co/card?avatar=${member.user.avatarURL({ format: 'png', size: 2048 })}&middle=Welcome&name=${member.user.username}%23${member.user.discriminator}&bottom=Now%20we%20have%20${member.guild.memberCount}%20members&background=https://i.ibb.co/64GS6fF/8-AB32533-3-F5-A-43-CB-94-FA-87-ED338682-DC.jpg`)
  .setFooter("Yokaze", client.user.avatarURL())
  .setTimestamp()
  .setColor('FF7300')

  member.guild.channels.cache.get(wChan).send(welEmbed)
})