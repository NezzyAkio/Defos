const discord = require("discord.js");

module.exports = {
  name: "invite",
  aliases: ['invitelink'],
  category: "information",
  description: "Get Invite Link of Bot",
  run: async (client, message, args) => {
    
    let embed = new discord.MessageEmbed()
    .setTitle(`Link Invite of Yokaze-Bot`)
    .setDescription(`• [Invite Me](https://yooaze.ml/invite)\n• [Support Server](https://support.yokaze.ml)\n• [Main Website](https://yokaze.ml)`)
    .setColor("#FF7300")
    .setFooter('Invite Link')
    .setTimestamp(message.timestamp = Date.now())
    
    message.channel.send(embed)
  }
}