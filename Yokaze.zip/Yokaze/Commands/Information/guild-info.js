const { MessageEmbed } = require('discord.js');
const { secondary } = require('../../assets/colors.json');
const { getTimeSince, formatDate } = require('../../tools');
const { regions } = require('../../assets/translation.json');

module.exports = {
  name: "guildinfo",
  aliases: ['ginfo', 'guild-info', 'server-info', 'sinfo', 's-i', 'g-i'],
  description: "Get the server information",
  usage: "guildinfo",
  category: "Information",
  run: async(client, message, args) => {
    const textChannels = [];
	const voiceChannels = [];
	const categories = [];
	for (const channel of message.guild.channels.cache) {
		if (channel[1].type === 'text') {
			textChannels.push(channel);
		}
		if (channel[1].type === 'voice') {
			voiceChannels.push(channel);
		}
		if (channel[1].type === 'category') {
			categories.push(channel);
		}
	}

	const e = new MessageEmbed()
		.setColor(secondary)
		.setTitle(`${message.guild.name}(${message.guild.id})`)
		.setThumbnail(message.guild.iconURL({ format: 'png' }))
		.setDescription(
			`${
				message.guild.description
					? `${message.guild.description}\n`
					: ''
			} **Owner**: ${message.guild.owner} \n**Region**: ${
				message.guild.region
			}\n**Guild Created**: ${formatDate(
				message.guild.createdAt,
			)} (*${getTimeSince(message.guild.createdAt)}*)`,
		)
		.addField(
			'Channels',
			`**Category ${client.emojis.cache.get('900564243806584902')} ${
				categories.length
			} \nText Channel ${client.emojis.cache.get('900564243684941884')} ${
				textChannels.length
			} \nVoice Channel ${client.emojis.cache.get('900564172234952784')} ${
				voiceChannels.length
			} \nAll Channel: ${message.guild.channels.cache.size}**`,
			true,
		)
		.addField('Members', `Total **${message.guild.memberCount}**`, true)
		.addField(
			'Misc.',
			`Roles **${message.guild.roles.cache.size}**\nEmojis **${message.guild.emojis.cache.size}**`,
			true,
		)
		.setFooter(`Yokaze`, client.user.avatarURL());

	if (message.guild.banner) {
		e.setImage(`${message.guild.bannerURL()}`);
	}
	return message.channel.send(e);
  }
}