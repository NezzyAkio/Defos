const { createEmbed } = require('../../utils/embed')
const agent = require('superagent')
const { sendSomeRandomAnimalAPI } = require('../../utils/helper');

module.exports = {
  name: "dog",
  aliases: ['doggie'],
  description: "Get a random picture and fact of a dog.",
  usage: "dog",
  category: "Images",
  run: async(client, message, args) => {
    return sendSomeRandomAnimalAPI(message, 'dog')
  }
}