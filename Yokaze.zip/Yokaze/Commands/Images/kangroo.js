const { createEmbed } = require('../../utils/embed')
const agent = require('superagent')
const { sendSomeRandomAnimalAPI } = require('../../utils/helper');

module.exports = {
  name: "kangroo",
  aliases: [''],
  description: "Get a random picture and fact of a kangroo.",
  usage: "kangroo",
  category: "Images",
  run: async(client, message, args) => {
    return sendSomeRandomAnimalAPI(message, 'kangroo')
  }
}