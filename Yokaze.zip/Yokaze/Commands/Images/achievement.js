const { createEmbed } = require('../../utils/embed')
const agent = require('superagent')

module.exports = {
  name: "achievemnt",
  aliases: ['mc', 'minecraft', 'mc-a', 'minecraft-achievement'],
  description: "Create your own minecraft achievements!",
  usage: "achievement <text>",
  category: "Images",
  run: async(client, message, args) => {
    const text = args[0] ? args.join(' ') : 'Please enter some text for achievement';
	if (text.length > 25) {
		return message.channel.send('Text must be under 25 characters.');
	}

	const { body } = await agent
		.get('https://www.minecraftskinstealer.com/achievement/a.php')
		.query({
			i: Math.floor(Math.random() * 39),
			h: 'Achievement Get!',
			t: text,
		});

	return message.channel.send({
		files: [{ attachment: body, name: 'achievement.png' }],
	});
  }
}