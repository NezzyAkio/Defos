const { createEmbed } = require('../../utils/embed')
const agent = require('superagent')
const { sendSomeRandomAnimalAPI } = require('../../utils/helper');

module.exports = {
  name: "raccoon",
  aliases: [''],
  description: "Get a random picture and fact of a raccoon.",
  usage: "raccoon",
  category: "Images",
  run: async(client, message, args) => {
    return sendSomeRandomAnimalAPI(message, 'raccoon')
  }
}