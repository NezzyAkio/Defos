const { createEmbed } = require('../../utils/embed')
const agent = require('superagent')
const { sendSomeRandomAnimalAPI } = require('../../utils/helper');

module.exports = {
  name: "cat",
  aliases: ['meow'],
  description: "Get a random picture and fact of a cat.",
  usage: "cat",
  category: "Images",
  run: async(client, message, args) => {
    return sendSomeRandomAnimalAPI(message, 'cat')
  }
}