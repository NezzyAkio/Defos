const { createEmbed } = require('../../utils/embed')
const agent = require('superagent')
const { sendSomeRandomAnimalAPI } = require('../../utils/helper')
const pandas = ['panda', 'red_panda']

module.exports = {
  name: "panda",
  aliases: [''],
  description: "Get a random picture and fact of a panda.",
  usage: "panda",
  category: "Images",
  run: async(client, message, args) => {
    var rand = pandas[Math.floor(Math.random() * pandas.length)]
    return sendSomeRandomAnimalAPI(message, rand)
  }
}