const agent = require('superagent');
const { createEmbed } = require('../../utils/embed')
const Discord = require('discord.js')

module.exports = {
  name: "fact",
  aliases: ['fun-fact', 'random-fact'],
  description: "Fun Fact: Did you know: it is illegal to eat oranges while bathing in California! Wait, doesn't Discord follows California law!? *drops orange* !",
  usage: "fact",
  category: "Fun",
  run: async(client, message, args) => {
    const res = await agent.get('https://uselessfacts.jsph.pl/random.json?language=en');

  let embed = new Discord.MessageEmbed()
    .setAuthor(`Fact`, message.author.avatarURL())
    .setDescription(res)
    .setFooter(`Requested by ${message.author.username}`)
    .setTimestamp()
    .setColor("#ff7300")

	return message.channel.send(embed)	 }
}