const { createEmbed, improperUsage } = require('../../utils/embed');
const agent = require('superagent')

module.exports = {
  name: "dad-joke",
  aliases: ['dad'],
  description: "Want to hear a punny dad joke? I got a few you might like!",
  category: "Fun",
  usage: "dad-joke",
  run: async(client, message, args) => {
    const res = await agent.get('https://icanhazdadjoke.com/slack');

	return message.channel.send(
		createEmbed({
			title: 'Dad Joke',
			body: res.body.attachments.map((a) => a.text),
		}),
	);
  }
}