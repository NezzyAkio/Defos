const Discord = require('discord.js');
const db = require('quick.db');

module.exports = {
  name: "setprefix",
  aliases: ['sprefix'],
  description: "To set bot prefix in current guild",
  usage: "setprefix <prefix>",
  category: "Moderation",
  run: async(client, message, args) => {
    if(!message.member.hasPermission("ADMINISTRATOR")) {
      let noPerm = new Discord.MessageEmbed()
      .setAuthor(`No Premission Detected!`, message.author.avatarURL())
      .setDescription(`You don't have permission in ${message.guild.name}`)
      .setTimestamp()
      .setColor("#FF7300")
      return message.channel.send(noPerm)
    }
    if(!args[0]) {
      let noArgs = new Discord.MessageEmbed()
      .setAuthor(`No Argument Detected!`, message.author.avatarURL())
      .setDescription(`Please type prefix that you want to change`)
      .setTimestamp()
      .setColor("#FF7300")
      return message.channel.send(noArgs)
    }
    if(args[1]) {
      let tooMuch = new Discord.MessageEmbed()
      .setAuthor('Double Arguments', message.author.avatarURL())
      .setDescription('Arguments cannot more than 1 because can me something wrong in bot')
      .setTimestamp()
      .setColor("#FF7300")
      return message.channel.send(tooMuch)
    }
    if(args.join("") === 'y/') {
      let resetPrefix = new Discord.MessageEmbed()
      .setAuthor(`Succesfully Reseted Prefix!`, message.author.avatarURL())
      .addField('Prefix succesfully reseted to ```y/```', 'Use ```y/help``` to see more commands available')
      .setTimestamp()
      .setColor("#FF7300")
      db.set(`prefix_${message.guild.id}`, args[0])
      return await message.channel.send(resetPrefix)
    }
    if(args[0].length > 3) {
      let tooMuchCharacter = new Discord.MessageEmbed()
      .setAuthor(`Character Too Much`, message.author.avatarURL())
      .setDescription('Please type prefix lower than 3 character')
      .setTimestamp()
      .setColor("#FF7300")
      return message.channel.send(tooMuchCharacter)
    }
    db.set(`prefix_${message.guild.id}`, args[0])
    
    let doneEmbed = new Discord.MessageEmbed()
    .setAuthor(`Succesfully change prefix to ${args[0]}`, client.user.avatarURL())
    .setThumbnail(message.author.avatarURL())
    .addField(`Prefix has been change to ${args[0]}`, `Use ${args[0]}help to see more commands`)
    .setFooter(`Changed by ${message.author.username}`, message.author.avatarURL())
    .setTimestamp()
    .setColor("#FF7300")
    await message.channel.send(doneEmbed)
  }
}