const Discord = require("discord.js");

module.exports = {
  name: "down",
  aliases: [''],
  description: "Status Server Up",
  usage: "up <message>",
  run: async(client, message, args) => {
    let note = args[0];
    if(!note) return message.channel.send('Put Your Reason')
      if(!message.member.hasPermission('ADMINISTRATOR')) return message.channel.send('Sorry You Need Admin Permission For Use This Command')
  
    
    let embed = new Discord.MessageEmbed()
    .setAuthor(`${message.guild.name} Status`)
    .setColor('#FF7300')
    .setThumbnail('https://cdn.discordapp.com/attachments/863844170666213386/885460586874417152/joged.gif')
    .addField('Server Status', `\`\`\`UP\`\`\``)
    .addField('Note', `\`\`\`${note}\`\`\``)
    .setImage('https://cdn.discordapp.com/attachments/863844170666213386/885460796728045598/rainbw.gif')
    .setFooter('Last Update')
    .setTimestamp()
    message.channel.bulkDelete(1)
    message.channel.send(embed)
  }
}