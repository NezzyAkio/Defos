const Discord = require('discord.js');
const { MessageEmbed } = require('discord.js');
const { creatorID: ownerid } = require('../../assets/config')

module.exports = {
  name: "stopbot",
  aliases: ['killbot'],
  description: "This Command Will Kill The Bot",
  usage: "stopbot",
  category: "Owner",
  run: async(client, message, args) => {
    if (message.author.id !== ownerid) return message.channel.send("You're not bot owner");
    
    const StopEmbed = new MessageEmbed()
    .setAuthor(`${client.user.username}`)
    .setDescription("Bot has Stopped")
    .setFooter(`Requested by ${message.author.tag}`)

    try {
      await message.channel.send(StopEmbed)
      process.exit(42)
    } catch(e) {
      message.channel.send(`ERROR: \`${e.message}\``)
    }
    
  }
}