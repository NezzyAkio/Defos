const { MessageEmbed } = require('discord.js');
const { PREFIX } = require('../../config');
const db = require('quick.db');

module.exports = {
  name: "store",
  aliases: ['shop'],
  description: "Store List",
  category: "economy",
  usage: "store",
  accesableby: "everyone",
 run: async (bot, message, args) => {
        let prefix;
        let fetched = await db.fetch(`prefix_${message.guild.id}`);

        if (fetched === null) {
            prefix = PREFIX
        } else {
            prefix = fetched
        }
      
        let embed = new MessageEmbed()
            .setDescription(`**VIP Ranks**\n\nBronze: 300000 Coins [${prefix}buy/${prefix}sell bronze]\n\n**Lifestyle Items**\n\nFresh Nikes: 800000 [${prefix}buy/${prefix}sell nikes]\nCar: 120000) [${prefix}buy/${prefix}sell car]\nMansion: 2000000 [${prefix}buy/${prefix}sell mansion]`)
            .setColor("#FF7300")
        message.channel.send(embed)
    }
}