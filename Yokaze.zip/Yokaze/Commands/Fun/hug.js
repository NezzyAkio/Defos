const discord = require("discord.js");
const { Random } = require("something-random-on-discord");
const random = new Random();

module.exports = {
  name: "hug",
  aliases: [''],
  category: "fun",
  description: "Hug someone",
  usage: "hug <mention | ID>",
  run: async (client, message, args) => {
    let target = message.mentions.members.first()
    
    let data = await random.getAnimeImgURL("hug");
    
    let embed = new discord.MessageEmbed()
    .setImage(data)
    .setColor("#FF7300")
    .setFooter(`${message.author.username} hugs ${target.user.username}`)
    .setTimestamp()
    
    message.channel.send(embed);
  }
};